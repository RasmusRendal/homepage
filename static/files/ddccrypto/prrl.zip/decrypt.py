#!/usr/bin/python3
# ▄▄▄  ▪        ▄▄▄▄▄     ▄▄▄·▄▄▄  ▄▄▄  ▄▄▌  
# ▀▄ █·██ ▪     •██      ▐█ ▄█▀▄ █·▀▄ █·██•  
# ▐▀▀▄ ▐█· ▄█▀▄  ▐█.▪     ██▀·▐▀▀▄ ▐▀▀▄ ██▪  
# ▐█•█▌▐█▌▐█▌.▐▌ ▐█▌·    ▐█▪·•▐█•█▌▐█•█▌▐█▌▐▌
# .▀  ▀▀▀▀ ▀█▄▀▪ ▀▀▀     .▀   .▀  ▀.▀  ▀.▀▀▀ 

import time
import sys
import random
from batkeys import get_key_with_length

# Split into blocks
def block_split(text):
    assert len(text) % block_size == 0

    blocks = []
    for i in range(0, len(text), block_size):
        blocks.append(text[i : i + block_size])
    return blocks

# XOR two byte strings
def byte_xor(A, B):
    return bytes([a ^ b for a, b in zip(A, B)])

# Simple block cipher decrypt
def block_cipher_decrypt(plaintext, key):
    assert len(plaintext) == len(key)
    return byte_xor(plaintext, key)


if __name__ == '__main__':
    # Global decryption parameters
    block_size = 8

    # Get the ciphertext to decrypt
    try:
        ciphertext = bytes.fromhex(sys.argv[1])
    except:
        print("You need to write your message as the first command-line argument, Astrid")
        sys.exit(0)

    # Calculate initialization vector
    # i guess i am making it calculatable.. it's a drag to have to include it..
    random.seed(time.time() // 3600 * 3600)
    init_vector = bytes([random.randint(0, 255) for x in range(block_size)])
    # [TODO] # encryption and decryption has to happen within the same hour.. I need to fix this part

    # Get byte string key with correct length
    key = get_key_with_length(len(ciphertext))

    # Split plaintext and key into blocks
    ciphertext_blocks = block_split(ciphertext)
    key_blocks = block_split(key)

    # Decryption
    ciphertext_for_cbc = init_vector
    plaintext = b''
    for ciphertext_block, key_block in zip(ciphertext_blocks, key_blocks):
        decrypted_block = block_cipher_decrypt(ciphertext_block, key_block)
        plaintext += byte_xor(decrypted_block, ciphertext_for_cbc)
        ciphertext_for_cbc = ciphertext_block

    # Unpad message
    message_length = plaintext.find(b'\x00')
    plaintext = plaintext[: message_length]

    # Print ciphertext as ascii
    print(plaintext.decode())
