#!/usr/bin/python3

# ▄▄▄  ▪        ▄▄▄▄▄     ▄▄▄·▄▄▄  ▄▄▄  ▄▄▌  
# ▀▄ █·██ ▪     •██      ▐█ ▄█▀▄ █·▀▄ █·██•  
# ▐▀▀▄ ▐█· ▄█▀▄  ▐█.▪     ██▀·▐▀▀▄ ▐▀▀▄ ██▪  
# ▐█•█▌▐█▌▐█▌.▐▌ ▐█▌·    ▐█▪·•▐█•█▌▐█•█▌▐█▌▐▌
# .▀  ▀▀▀▀ ▀█▄▀▪ ▀▀▀     .▀   .▀  ▀.▀  ▀.▀▀▀ 

import time
import sys
import random
from batkeys import get_key_with_length

# Split into blocks
def block_split(text):
    assert len(text) % block_size == 0

    blocks = []
    for i in range(0, len(text), block_size):
        blocks.append(text[i : i + block_size])
    return blocks

# XOR two byte strings
def byte_xor(A, B):
    return bytes([a ^ b for a, b in zip(A, B)])

# Simple block cipher encrypt
def block_cipher_encrypt(plaintext, key):
    assert len(plaintext) == len(key)
    return byte_xor(plaintext, key)


if __name__ == '__main__':
    # Global encryption parameters
    block_size = 8

    # Get the plaintext to encrypt
    if len(sys.argv) != 2:
        print("You need to write your message as the first command-line")
        print("argument, Astrid")
        sys.exit(0)
    plaintext = sys.argv[1].encode('utf-8')

    # Pad message
    # Padded message should be a multiple of the block size
    padding_length = -len(plaintext) % block_size
    plaintext += b'\x00' * padding_length

    # Get byte string key with correct length
    key = get_key_with_length(len(plaintext))

    # Split plaintext and key into blocks
    plaintext_blocks = block_split(plaintext)
    key_blocks = block_split(key)

    # Calculate initialization vector
    # i guess i am making it calculatable.. it's a drag to have to include it..
    random.seed(time.time() // 3600 * 3600)
    init_vector = bytes([random.randint(0, 255) for x in range(block_size)])
    # [TODO] # encryption and decryption has to happen within the same hour..
    # I need to fix this part

    # Encryption
    ciphertext = init_vector
    for plaintext_block, key_block in zip(plaintext_blocks, key_blocks):
        block_to_encrypt = byte_xor(plaintext_block, ciphertext[-block_size :])
        ciphertext += block_cipher_encrypt(block_to_encrypt, key_block)

    # Remove init vector from ciphertext
    ciphertext = ciphertext[block_size :]

    # Print ciphertext as hex
    print(ciphertext.hex())     # Convert hex string to byte string with
                                # `bytes.fromhex(some_hexstring)`
